#ifndef _INCLUDES_H
#define _INCLUDES_H

#define ROOT system

#include "quagga.h"

#endif
